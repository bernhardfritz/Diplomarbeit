cd bin
./startup.sh
exit