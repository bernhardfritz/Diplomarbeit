cd bin
./shutdown.sh
exit